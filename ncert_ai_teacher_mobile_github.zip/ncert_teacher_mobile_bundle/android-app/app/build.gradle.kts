plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ncertteacher.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ncertteacher.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    dependencies {
        implementation("androidx.appcompat:appcompat:1.7.0")
        implementation("androidx.activity:activity-ktx:1.9.3")
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
